def display_info():
    
    name = "Jonathan Morrow"
    address = "16825 Bristlecone Road, USA"
    telephone = "(918) 758-6028"

    print("Name:", name)
    print("Address:", address)
    print("Telephone:", telephone)

if __name__ == "__main__":
    display_info()
