def compute_circle_area():
    
    radius = float(input("Enter the radius of the circle: "))

    
    area = 3.14 * radius ** 2

    
    print(f"The area of the circle with radius {radius} is: {area}")

if __name__ == "__main__":
    compute_circle_area()
